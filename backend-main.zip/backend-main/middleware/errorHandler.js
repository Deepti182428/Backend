//errorhandler
exports.errorHandler=async (err,req,res,next)=> {
    try{
        const statusCode=err.statusCode || 500;
        const errorResponce={
            message:err.message||"internal server error",
            error:err
            
        }
        console.log(err)
        res.status(statusCode).json(errorResponce)
    }catch(e){
     next(e)
    }
}