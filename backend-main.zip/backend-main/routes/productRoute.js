//productRoutes.js
const express=require("express");
const router=express.Router();
const {createProduct ,getAllProducts,getProductById,updateProductById,deleteProductById}=require("../controller/ProductController");
const { auth }=require("../middleware/auth");
const upload = require("../middleware/upload");


router.post ("/",auth ,upload.single("image"),createProduct)
router.get("/",getAllProducts);
router.get("/:id",getProductById);
router.put("/:id", upload.single("image"),updateProductById);
router.delete("/:id",deleteProductById);



module.exports=router