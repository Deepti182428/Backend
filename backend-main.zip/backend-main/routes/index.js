//index.js
const express=require("express")
const productsRoute=require("./productRoute")
const userRoutes=require("./userRoute")
const authRoute=require("./authRoute")
const cartRoute=require("./cartRoute")
const { auth } = require("../middleware/auth")
const orderRoutes=require("./orderRoutes")
const ratingRoute=require("./ratingRoute")

const routes=express.Router();

routes.use("/users",userRoutes);
routes.use("/products",productsRoute);
routes.use("/auth",authRoute);
routes.use("/carts",auth ,cartRoute);

routes.use("/orders", auth, orderRoutes);

routes.use("/ratings",auth, ratingRoute);


module.exports=routes;



