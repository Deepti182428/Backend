const mongoose=require("mongoose");
//product.js
//model
const productSchema=new mongoose.Schema({
    name:{type:String,required:true},
        category:{type:String,required:true},
        description:{type:String,required:true},
        price:{type:Number,required:true},
        quantity:{type:Number,required:true},
        rating:{type:Number},
        imageUrl:{type:String,required:true}
},{
    timeStamps:true
})

const ProductModel=mongoose.model("Product",productSchema)

module.exports=ProductModel