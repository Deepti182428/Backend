const mongoose=require("mongoose");
//model
//token.js
const OrderSchema=new mongoose.Schema({
    userid:{
        type:mongoose.Schema.Types.ObjectId(ObjectId),
        required:true,
        ref:"User"
    },
    TokenId:{
    type:String,required:true
    }
},{timeStamps:true})


const TokenModel=mongoose.model("Token",TokenSchema)


module.exports=TokenModel
