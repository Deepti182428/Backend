//control the product 
//productcontroller
const ProductModel = require("../model/Product");
const Rating =require("../model/Rating")

exports.createProduct=async(req,res,next)=>
{
      let {name,category,description,price,quantity,imageUrl}=req.body;
    try{
       if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }
        const product=await ProductModel.create({name ,category,description,price,quantity,imageUrl});
 res.status(201).json({
    massage:"product created successfully",product})
    }catch(error)
    {
        next(error)
    }
}


//geting all products
exports.getAllProducts=async(req,res,next)=>{
    try{
const Products=await ProductModel.find();
res.status(200).json(Products)
    }catch(error){
next(error)
    }
}

///geting single product details

exports.getProductById=async(req,res,next)=>{
    const{id}=req.params;
    try{
const product=await ProductModel.findById(id);
if(!product)
{
    const error=new error("product does not exist");
    error.statusCode=400;
    throw error
}
 const ratings = await Rating.find({ id });


 let averageRating = 0;
    if (ratings.length > 0) {
      const sum = ratings.reduce((total, rating) => total + rating.rating, 0);
      averageRating = sum / ratings.length;
    }
    const response = {
      ...product.toObject(),
      averageRating: parseFloat(averageRating.toFixed(1)),
      totalRatings: ratings.length,
      outOf5: 5,
    };

    res.json(response);

res.status(200).json(product)
    }catch(error){
    next(error)
    }
}

exports.updateProductById=async(req,res,next)=>{
    const{id}=req.params;
    const {name,category,description,price,quantity,imageUrl}=req.body;
    try{
        const product=await ProductModel.findById(id);
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }
if(!product){

    const error=new error("product does not exist");
    error.statusCode=400;
    throw error
}
const updateProduct=await ProductModel.updateOne({_id:id},{$set:{
    name,description,category,price,quantity,imageId}})
res.status(200).json({massage:"product updeted",Product:update})
}catch(error){
        next(error)
    }
}





//to delete the product

exports.deleteProductById=async(req,res,next)=>{
    const{id}=req.params;
    try{
        const deleteProduct=await ProductModel.findByIdAndDelete(id)
        if(!deleteProduct){
            const error=new error("product does not exist");
             error.statusCode=400;
    throw error

        }
        res.status(200).json({massage:"product deleted successfully"})
    }catch(error){
        console.log(error)
        next(error)
    }
}


